
public class RoachSimulation {

	public static void main(String[] args) {
		
		RoachPopulation bugs = new RoachPopulation();
		bugs.initialPopulation(10);
		System.out.println("The Initial Roach population is " + bugs.getRoaches());
		bugs.breed();
		
		System.out.println("\nThe Roach Population after cycle 1 breeding is " + bugs.getRoaches());
		bugs.spray(50);
		
		System.out.println("\nThe Roach Population after cycle 1 50% spraying is " + bugs.getRoaches());
		bugs.breed();
		
		
		System.out.println("\nThe Roach Population after cycle 2 breeding is " + bugs.getRoaches());
		bugs.spray(60);
		
		System.out.println("\nThe Roach Population after cycle 2 60% spraying is " + bugs.getRoaches());
		bugs.breed();
		
		System.out.println("\nThe Roach Population after cycle 3 breeding is " + bugs.getRoaches());
		bugs.spray(70);
		
		System.out.println("\nThe Roach Population after cycle 3 70% breeding is " + bugs.getRoaches());
		bugs.breed();
		
		System.out.println("\nThe Roach Population after cycle 4 breeding is " + bugs.getRoaches());
		bugs.spray(80);
		
		System.out.println("\nThe Roach Population after cycle 4 80% spraying is " + bugs.getRoaches());

	}

}
