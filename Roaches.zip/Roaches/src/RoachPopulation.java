
public class RoachPopulation {

	private double currentPopulation;
	
	public void currentPop() {
		currentPopulation = 0;
	}
	
	//initial population 
	public void initialPopulation(double population) {
		currentPopulation = population;
	}
	
	//breed method
	public void breed() {
		currentPopulation = currentPopulation * 2;
	}
	
	//spray method
	public void spray(double percent) {
		percent = currentPopulation * percent;
		percent = (double) (percent * 0.01);
		currentPopulation = (currentPopulation - percent);
	}
	
	//getRoaches method
	public double getRoaches() {
		return currentPopulation;
	}

}
